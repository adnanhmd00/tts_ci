<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    
	
	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-EE16CRYW41"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-EE16CRYW41');
</script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.js"></script>
    <link rel="stylesheet" type="text/css" href="slick/slick.css">
  <link rel="stylesheet" type="text/css" href="slick/slick-theme.css">
    <link rel="stylesheet" href="style.css">

   
  </head>
  <body>
		
       <header id="privacy-policy">
           <div class="dark-overlay">
               <div class="home-inner container">
                   <div class="row">
                       <div class="col-md-12">
                            <div class="text">
                                <center><h1><small>Terms & Conditions</small></h1>
                                <p>The Travel Square App & Website</p></center>
                            </div>
                            
                       </div>
                   </div>
               </div>
           </div>
       </header>
		<br>
		
		
				 
				  <br>
				  <div class="text-muted py-4 mb-2">
				  
				 
                <div class="container">
				<font color="black">
				
				<h5>Welcome to The Travel Square</h5>

<p>These terms and conditions outline the rules and regulations for the use of The Travel Square (TM), Hashtrek Travel Private Limited's Website, located at <a href="http://thetravelsquare.in/" targe="_blank"><font color="sky-blue"><u>https://thetravelsquare.in/</u></font></a> .</p>

<p><b>Important Message : By accessing this website we assume you accept these <a href="http://thetravelsquare.in/" targe="_blank"><font color="sky-blue"><u>Term & Conditions</u></font></a> . Do not continue to use The Travel Square if you do not agree to take all of the terms and conditions stated on this page.</b></p>


<hr>


<h5>Introduction</h5>
<p>This Terms of Service Agreement (hereinafter "Agreement") sets forth the terms and conditions by which we,  provide the The Travel Square Trade Mark by Hashtrek Travel Private Limited  Application Services to site visitors, users, registered members and account holders. By visiting our site, using any of the tools and services provided via our site, or registering an account, you thereby agree to be bound by each of the terms and conditions of this Agreement.<br><br>

We may automatically amend this Agreement at any time by informing you of the amended terms via email to an email address you provide to us, if you are a registered account holder. Such amendments will be effective when sent to your last known email address. It is your duty to keep your email address up to date and to maintain a valid email address and to ensure that emails we send you are not filtered or stopped by spam filters or other types of email blocking functionalities. Alternatively, we may merely post the amended terms and make them available to be read by current account holders. In such cases, the modified terms and conditions of this Agreement are effective and in force when posted by us.<br><br>

For those visitors to The Travel Square Trade Mark by Hashtrek Travel Private Limited  who have not registered as users, or who have let their memberships elapse, it is their responsibility to read this Terms of Service each time they access any portion of our site. Any usage of this site by you, including merely viewing our home page or any page published on our site, as an unregistered The Travel Square Trade Mark by Hashtrek Travel Private Limited  user, means that you agree to be bound by each and every one of the terms and conditions of this Terms of Service Agreement.<br></p>

<hr>

<h5>Definitions</h5>
<p>
The following terminology applies to these Terms and Conditions, Privacy Statement and Disclaimer Notice and all Agreements: "Client", "You" and "Your" refers to you, the person log on this website and compliant to the Company’s terms and conditions. "The Company", "Ourselves", "We", "Our" and "Us", refers to our Company. "Party", "Parties", or "Us", refers to both the Client and ourselves. All terms refer to the offer, acceptance and consideration of payment necessary to undertake the process of our assistance to the Client in the most appropriate manner for the express purpose of meeting the Client’s needs in respect of provision of the Company’s stated services, in accordance with and subject to, prevailing law of Netherlands. Any use of the above terminology or other words in the singular, plural, capitalization and/or he/she or they, are taken as interchangeable and therefore as referring to same.</p>

<hr>

<h5>Usage of Cookies</h5>
<p>We employ the use of cookies. By accessing The Travel Square, you agreed to use cookies in agreement with the Hashtrek Travel Private Limited's 
<a href="http://thetravelsquare.in/privacypolicy" targe="_blank"><font color="sky-blue">Cookie Privacy Policy</font></a> .<br><br>

Most interactive websites use cookies to let us retrieve the user’s details for each visit. Cookies are used by our website to enable the functionality of certain areas to make it easier for people visiting our website. Some of our affiliate/advertising partners may also use cookies.</p>

<hr>

<h5>License</h5>
<p>Unless otherwise stated, Hashtrek Travel Private Limited and/or its licensors own the intellectual property rights for all material on The Travel Square. All intellectual property rights are reserved. You may access this from The Travel Square for your own personal use subjected to restrictions set in these terms and conditions.</p>

<p>You must not:</p>

<p>1. Republish material from The Travel Square</p>
<p>2. Sell, rent or sub-license material from The Travel Square</p>
<p>3. Reproduce, duplicate or copy material from The Travel Square</p>
<p>4. Redistribute content from The Travel Square</p>

<p>This Agreement shall begin on the date here of.</p>

<p>Parts of this website offer an opportunity for users to post and exchange opinions and information in certain areas of the website. Hashtrek Travel Private Limited does not filter, edit, publish or review Comments prior to their presence on the website. Comments do not reflect the views and opinions of Hashtrek Travel Private Limited,its agents and/or affiliates. Comments reflect the views and opinions of the person who post their views and opinions. To the extent permitted by applicable laws, Hashtrek Travel Private Limited shall not be liable for the Comments or for any liability, damages or expenses caused and/or suffered as a result of any use of and/or posting of and/or appearance of the Comments on this website.</p>

<p>Hashtrek Travel Private Limited reserves the right to monitor all Comments and to remove any Comments which can be considered inappropriate, offensive or causes breach of these Terms and Conditions.</p>

<p>You warrant and represent that:</p>

<p>- You are entitled to post the Comments on our website and have all necessary licenses and consents to do so;</p>
<p>- The Comments do not invade any intellectual property right, including without limitation copyright, patent or trademark of any third party;</p>
<p>- The Comments do not contain any defamatory, libelous, offensive, indecent or otherwise unlawful material which is an invasion of privacy</p>
<p>- The Comments will not be used to solicit or promote business or custom or present commercial activities or unlawful activity.</p>

<p>You hereby grant Hashtrek Travel Private Limited a non-exclusive license to use, reproduce, edit and authorize others to use, reproduce and edit any of your Comments in any and all forms, formats or media.</p>

<hr>

<h5>Hyperlinking to our Content</h5>
<h6>The following organizations may link to our Websites without prior written approval</h6>

<p>a. Government agencies</p>
<p>b. Search engines</p>
<p>c. News organizations</p>
<p>d. Online directory distributors / Partners / Affiliates may link to our Website in the same manner as they hyperlink to the Websites of other listed businesses</p>
<p>e. System wide Accredited Businesses except soliciting non-profit organizations, charity shopping malls, and charity fundraising groups which may not hyperlink to our Web site.</p><br>
<h6>These organizations may link to our home page, to publications or to other Website information so long as the link: </h6>
<p>a. is not in any way deceptive</p>
<p>b. does not falsely imply sponsorship, endorsement or approval of the linking party and its products and/or services</p>
<p>c. fits within the context of the linking party’s site</p><br>

<h6>We may consider and approve other link requests from the following types of organizations:</h6>
<p>a. Commonly-known consumer and/or business information sources</p>
<p>b. Dot.com community sites</p>
<p>c. Associations or other groups representing charities</p>
<p>d. Online directory distributors</p>
<p>e. Internet portals</p>
<p>f. Accounting, law and consulting firms</p>
<p>g. Educational institutions and trade associations</p>

<br>

<h6>We will approve link requests from these organizations if we decide that:</h6>
<p>a. The link would not make us look unfavorably to ourselves or to our accredited businesses</p>
<p>b. The organization does not have any negative records with us</p>
<p>c. The benefit to us from the visibility of the hyperlink compensates the absence of Hashtrek Travel Private Limited</p>
<p>d. The link is in the context of general resource information.</p>

<br>

<h6>These organizations may link to our home page so long as the link:</h6>
<p>a. Is not in any way deceptive</p>
<p>b. does not falsely imply sponsorship, endorsement or approval of the linking party and its products or services</p>
<p>c. fits within the context of the linking party’s site</p>

<br>

<p>If you are one of the organizations listed in paragraph 2 above and are interested in linking to our website, you must inform us by sending an e-mail to Hashtrek Travel Private Limited. Please include your name, your organization name, contact information as well as the URL of your site, a list of any URLs from which you intend to link to our Website, and a list of the URLs on our site to which you would like to link. Wait 2-3 weeks for a response.</p>

<h6>Approved organizations may hyperlink to our Website as follows:</h6>
<p>- By use of our corporate name</p>
<p>- By use of the uniform resource locator being linked to</p>
<p>- By use of any other description of our Website being linked to that makes sense within the context and format of content on the linking party’s site</p>

<br>

<p>No use of Hashtrek Travel Private Limited's logo or other artwork will be allowed for linking absent a trademark license agreement.</p>

<hr>


<h5>iFrames</h5>
<p>Without prior approval and written permission, you may not create frames around our Webpages that alter in any way the visual presentation or appearance of our Website.</p>

<hr>


<h5>Content Liability</h5>
<p>We shall not be hold responsible for any content that appears on your Website. You agree to protect and defend us against all claims that is rising on your Website. No link(s) should appear on any Website that may be interpreted as libelous, obscene or criminal, or which infringes, otherwise violates, or advocates the infringement or other violation of, any third party rights.</p>

<hr>



<h5>Your Privacy</h5>
<p>Please Read The <a href="http://thetravelsquare.in/privacypolicy" targe="_blank"><font color="sky-blue">Privacy Policy</font></a> .</p>

<hr>


<h5>Reservation of Rights</h5>
<p>We reserve the right to request that you remove all links or any particular link to our Website. You approve to immediately remove all links to our Website upon request. We also reserve the right to amen these terms and conditions and it’s linking policy at any time. By continuously linking to our Website, you agree to be bound to and follow these linking terms and conditions.</p>

<hr>



<h5>Removal of links from our website</h5>
<p>If you find any link on our Website that is offensive for any reason, you are free to contact and inform us any moment. We will consider requests to remove links but we are not obligated to or so or to respond to you directly.</p>
<p>We do not ensure that the information on this website is correct, we do not warrant its completeness or accuracy; nor do we promise to ensure that the website remains available or that the material on the website is kept up to date.</p>

<hr>



<h5>Our Commitment to You</h5>
<p>We are committed to bringing you the best possible tools and services designed to meet your needs and expectations. We promise you that our The Travel Square Trade Mark by Hashtrek Travel Private Limited  Application Services will be available at least 99.9% of the time, excluding those periods where we conduct regularly scheduled maintenance or where unforeseeable and unavoidable service outages occur due to Internet, router, or Internet Service Provider related downtime outside of our control. While we are not and cannot be responsible for your own connection to the Internet, or the functionality of your own private systems or software existing outside of our The Travel Square Trade Mark by Hashtrek Travel Private Limited  Network, we guarantee that you will, except for those conditions mentioned above, be able to access the The Travel Square Trade Mark by Hashtrek Travel Private Limited  Application Services 99.9% of the time.</p>

<hr>



<h5>Limited Warranty</h5>
<p>If for some reasons the The Travel Square Trade Mark by Hashtrek Travel Private Limited  Application Services do not meet our stringent standard of availability, you may request a refund in the amount of 5% of your Monthly License Fee. Refunds will be issued in the form of a credit towards your next invoice, unless the affected month was pre-established by you as your final month of service, and you have informed us of that in writing prior to the service outage and in such cases your refund will be issued via check or credit card order (at our sole option) within 60 days of your request and upon our verification of the service outage, including the actual amount of downtime.</p>

<hr>



<h5>Scheduled Maintenance</h5>
<p>We makes every effort to perform all service maintenance activities during pre-scheduled maintenance windows. Currently, the maintenance windows are set for Friday and Saturday evenings, from 10:00 p.m. to 2:00 a.m. Indian Standard Time, We may not utilize every maintenance window. If system downtime is planned during any maintenance window, we will issue an announcement prior to the date of the planned maintenance activity.</p>

<hr>



<h5>Billing Policies</h5>
<p>1. You will be billed for services you have selected to receive on a recurring basis until and unless the service(s) we are providing is cancelled by you. You may select from monthly, quarterly, or yearly recurring billing plans. By accepting any of our services, you agree to keep us updated as to your billing information.</p>
<p>2. Accounts that have become delinquent (more than 10 days past due) are subject to deactivation without further notice being given to you.</p>
<p>3. Our charges are not based upon actual usage of the The Travel Square Trade Mark by Hashtrek Travel Private Limited  service, but instead, are based upon a license fee that entitles you to use the The Travel Square Trade Mark by Hashtrek Travel Private Limited  service. You must specifically cancel any service that you no longer wish to use and pay for.</p>
<p>4. You agree to hold our company, its officers, directors, employees, partners, affiliates and associates harmless and indemnify and defend from any civil claim of any nature that arises from your usage of the The Travel Square Trade Mark by Hashtrek Travel Private Limited  Application Services. You agree to be bound by the terms and conditions of our Acceptable Use Policy which is hereby incorporated by reference as if fully set forth herein.</p>

<hr>



<h5>Termination & Additional Terms</h5>
<p>1. We may terminate this Agreement immediately for any reason without notice to you. Your account will be terminated if you violate any of the terms and conditions of this Agreement.</p>
<p>2. WE PROVIDE YOUR ACCOUNT AND OUR SERVICES ON AN "AS IS" BASIS, SUBJECT TO THE LIMITED WARRANTY PROVIDED HEREIN, OUR SUPPLIERS, PARTNERS AND AFFILIATES, IF ANY, AND WE EXPRESSLY DISCLAIM ALL WARRANTIES OR CONDITIONS OF ANY KIND, SAVE FOR OUR LIMITED WARRANTY PROVIDED HEREIN, INCLUDING ALL FURTHER AND ADDITIONAL EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF TITLE, NONINFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. You understand and agree that our services may be unavailable for extended periods of time, and we do not warrant or ensure the continuous availability of our services. We may discontinue any or all services provided to you at any time without notice to you. Some states do not allow the disclaimer of implied warranties, so the foregoing disclaimer may not apply to you. We should not be liable for any delay or failure to perform resulting directly or indirectly from any causes beyond our control.</p>
<p>3. IN NO EVENT SHALL OUR SUPPLIERS, PARTNERS, AFILLIATES OR WE BE LIABLE FOR ANY LOST PROFITS OR SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES (HOWEVER ARISING, INCLUDING NEGLIGENCE) ARISING OUT OF OR IN CONNECTION WITH YOUR ACCOUNT OR THIS AGREEMENT. OUR LIABILITY TO YOU OR ANY THIRD PARTIES IS LIMITED TO THE REMEDIES PROVIDED THROUGH OUR LIMITED WARRANTY. Some states do not allow the foregoing limitations of liability, so they may not apply to you.</p>
<p>4. If any provision of this Agreement is held by a court of competent jurisdiction to be invalid or unenforceable, all unaffected provisions or elements should remain in full force and effect. Any failure on our part to enforce any portion of this Agreement does not serve to waive the enforceability of the remaining portions or other breaches on your part regarding this Agreement.</p>
<p>5. This Agreement sets forth the entire understanding and agreement between us with respect to the subject matter here of.</p>

<hr>

<h5>Disclaimer</h5>
<p>To the maximum extent permitted by applicable law, we exclude all representations, warranties and conditions relating to our website and the use of this website. Nothing in this disclaimer will:</p>
<p>a. limit or exclude our or your liability for death or personal injury</p>
<p>b. limit or exclude our or your liability for fraud or fraudulent misrepresentation</p>
<p>c. limit any of our or your liabilities in any way that is not permitted under applicable law</p>
<p>d. exclude any of our or your liabilities that may not be excluded under applicable law</p>

<hr>

<h5>Consent</h5>

<p>By using our website, you hereby consent to our <font color="sky-blue"><a href="http://thetravelsquare.in/termsandconditions"><u>Terms and Conditions.</u></a></font> and agree to it. </p>

<hr>

<h5>FAQ's & concerns</h5>

<p>If you have any questions or concerns, or if you wish to update, delete, or change any personal information we hold, please contact us at <font color="sky-blue"><a href="mailto:info@thetravelsquare.in">info@thetravelsquare.in</a></font></p>

<hr>

<h5>Contact</h5>
<p>Should you have any inquiries or doubts regarding our <font color="sky-blue"><a href=""><u>Terms and Conditions.</u></a></font> or applied procedures feel free to contact us via the following e-mail: <font color="sky-blue"><a href=""><font color="sky-blue"><a href="mailto:info@thetravelsquare.in">info@thetravelsquare.in</a></font></a></font> .</p>
				
				</font>
                </div>
        </div>
		

   

     

     <footer class="footer bg-black py-5">
        <div class="container">
            <div class="row">
				<div class="offset-md-2 col-md-4"><br>
                    <a href="http://business.thetravelsquare.in/" target="_blank">
					<img style="width: 65%; height: 97px;" src="./img/the-travel-square-indias-largest-b2b-travel-network.png" alt="the-trave-square-logo" class="img-fluid mx-auto d-block">
					</a>
                </div>
                <div class="col-md-6"><br><br>
                   <font size="2" color="white"><h5>India's Largest Travel Network</h5>
				    <p>
					Our Smart Technology Driven AI Platform Enables The Customers to Explore Places , Select There Priorities While Travelling, 
					Building creative Itineraries Following their Tastes and likkings at best possible rates, Enabling them to compare prices intelligently Saving Time and Effort , ensuring complete satisfaction and service for their vacations and business trips .

					</p>
				   </font>
				</div>
                
            </div>
            <hr color="white">
			<font size="2">
            
			
            
            <div class="container py-4">
                <div class="row">
					<div class="col-md-3">
                        
                        <div class=""><small><center>
                           <a class="text-light" href="https://www.facebook.com/thetravelsquareb2b" target="_blank" rel=”nofollow”><i class="fa fa-facebook fa-2x ml-3"></i></a>
                           <a class="text-light" href="https://twitter.com/travelsquareb2b" target="_blank" rel=”nofollow”><i class="fa fa-twitter fa-2x ml-3"></i></a>
                           <a class="text-light" href="https://www.instagram.com/thetravelsquareofficial/" target="_blank" rel=”nofollow”><i class="fa fa-instagram fa-2x ml-3"></i></a>
                           <a class="text-light" href="https://www.linkedin.com/company/thetravelsquareb2b" target="_blank" rel=”nofollow”><i class="fa fa-linkedin fa-2x ml-3"></i></a>
                           <a class="text-light" href="https://www.linkedin.com/company/thetravelsquareb2b" target="_blank" rel=”nofollow”><i class="fa fa-youtube fa-2x ml-3"></i></a>
                           </small></center>
						  <br>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <center>
						
                        <i class="fa fa-phone text-muted mb-2"></i> &nbsp; <a href="tel:9999007037"><font color="white">+91-8595-9027-52 | 11-406-401-87</font></a>
						</center>
					</div>
                    <div class="col-md-3">
						<center>
                        
                        <i class="fa fa-envelope text-muted mb-2"></i> &nbsp;<a href="mailto:info@thetravelsquare.in"><font color="white">info@thetravelsquare.in</font></a
						</center>
                    </div>
                    
					<div class="col-md-3">
						<center>
                        <p class="text-muted mt-2">
							
                               <a href="http://www.thetravelsquare.in/"><font color="white" ><big>The Travel Square</big></a> <br><small>&copy; 2022 All Rights Reserved <br></small>
                               </font>
						</center>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>


  </body>
</html>
