<!DOCTYPE html>

<html lang="en">
    <!-- begin::Head -->
	
	
<title>PPC Campaign | TTS APP</title>	


<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<head>
     
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="http://partner.thetravelsquare.in/resource/admin/files/css">
<link href="http://partner.thetravelsquare.in/resource/admin/files/login-1.css" rel="stylesheet" type="text/css">
<link href="" rel="stylesheet" type="text/css">
<link href="http://partner.thetravelsquare.in/resource/admin/files/plugins.bundle.css" rel="stylesheet" type="text/css">
<link href="http://partner.thetravelsquare.in/resource/admin/files/style.bundle.css" rel="stylesheet" type="text/css">
<link href="http://partner.thetravelsquare.in/resource/admin/files/fullcalendar.bundle.css" rel="stylesheet" type="text/css">
<link href="http://partner.thetravelsquare.in/resource/admin/files/dark.css" rel="stylesheet" type="text/css">
<link href="http://partner.thetravelsquare.in/resource/admin/files/dark(1).css" rel="stylesheet" type="text/css">
<link href="http://partner.thetravelsquare.in/resource/admin/files/dark(2).css" rel="stylesheet" type="text/css">
<link href="http://partner.thetravelsquare.in/resource/admin/files/dark(3).css" rel="stylesheet" type="text/css">     
<link rel="shortcut icon" href="#">

<script async="" src="http://partner.thetravelsquare.in/resource/admin/files/modules.3a2c212c6000288ee2ae.js.download" charset="utf-8"></script>
<script type="text/javascript" charset="UTF-8" src="./files/common.js.download"></script>
<script type="text/javascript" charset="UTF-8" src="http://partner.thetravelsquare.in/resource/admin/files/util.js.download"></script>   
<script async src="https://www.googletagmanager.com/gtag/js?id=G-EE16CRYW41"></script>

<script>
    window.dataLayer = window.dataLayer || [];
    function gtag() { dataLayer.push(arguments); }
    gtag('js', new Date());

    gtag('config', 'G-EE16CRYW41');
</script> 

<style type="text/css">
    iframe#_hjRemoteVarsFrame {
        display: none !important;
        width: 1px !important;
        height: 1px !important;
        opacity: 0 !important;
        pointer-events: none !important;
    }
</style>

<style type="text/css">/* Chart.js */
/*
* DOM element rendering detection
* https://davidwalsh.name/detect-node-insertion
*/
@keyframes chartjs-render-animation {
from { opacity: 0.99; }
to { opacity: 1; }
}

.chartjs-render-monitor {
animation: chartjs-render-animation 0.001s;
}

/*
* DOM element resizing detection
* https://github.com/marcj/css-element-queries
*/
.chartjs-size-monitor,
.chartjs-size-monitor-expand,
.chartjs-size-monitor-shrink {
position: absolute;
direction: ltr;
left: 0;
top: 0;
right: 0;
bottom: 0;
overflow: hidden;
pointer-events: none;
visibility: hidden;
z-index: -1;
}

.chartjs-size-monitor-expand > div {
position: absolute;
width: 1000000px;
height: 1000000px;
left: 0;
top: 0;
}

.chartjs-size-monitor-shrink > div {
position: absolute;
width: 200%;
height: 200%;
left: 0;
top: 0;
}
</style>

</head>
    <!-- end::Head -->
    <!-- begin::Body -->
    <body class="kt-quick-panel--right kt-demo-panel--right kt-offcanvas-panel--right kt-header--fixed kt-header-mobile--fixed kt-aside--enabled kt-aside--fixed">
        <!-- begin:: Page -->
        <!-- begin:: Header Mobile -->
        
        <!-- end:: Header Mobile -->	
        <div class="kt-grid kt-grid--hor kt-grid--root">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
                <!-- begin:: Aside -->
               
                <!-- end:: Aside -->
                <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">
                    <!-- begin:: Header -->
                    
                    <!-- end:: Header -->
                    <div class="kt-content  kt-content--fit-top  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">
                        <!-- begin:: Content -->
                        <!-- begin:: Hero --><br><br>
                        <div class="kt-sc" style="height:400px;background-image: url(<?= base_url('uploads/b2b/black-banner.png');?>)"  height="320" width="900" >
                            <div class="kt-container ">
                                <div class="kt-sc__top">
                                    <h3 class="kt-sc__title"><br>
                                        <font color="white">Pay Per Click Campaign
                                    </h3>
                                </div>
                                <div class="kt-sc__bottom">
                                    <h3 style="margin-top:150px;" class="kt-sc__heading kt-heading kt-heading--center kt-heading--xxl kt-heading--medium">
                                        <font color="white" >TRAVEL SQUARE <b><big><font size="12">ADS</font></big></b></font>
                                    </h3>
                                </div>
                            </div>
                        </div>
                        <!-- end:: Hero -->
                        <!-- begin:: Section -->
                        <!-- end:: iconbox -->
                        <!-- begin:: Section -->
                        <!-- end:: Section -->
                        <!-- begin:: Section -->
                        <div class="kt-container " style="margin-top:50px;">
                            <div class="kt-portlet">
                                <div class="kt-portlet__body">
                                    <div class="kt-infobox">
                                        <div class="kt-infobox__header">
                                            <h2 class="kt-infobox__title">Ads | Pay Per Click Campaign</h2>
                                        </div>
                                        <div class="kt-infobox__body">
                                            <div class="kt-infobox__section">
                                                <h3 class="kt-infobox__subtitle">About PPC Campaign</h3>
                                                <div class="kt-infobox__content">
                                                    The Pay Per Click or PPC Campaign By The Travel Square is an Advertisnment Platform Where Brands Can Advertise There Deals , Brands and 
                                                    Much More To Generate Leads From a Niche Traffic That is Community of Travellers . Contact Us To Submit Your Digital Advertisnments and 
                                                    Understand Add Plans To Publish And Advertise Your Posts
                                                </div>
                                            </div>
                                            <div class="kt-infobox__section">
                                                <h3 class="kt-infobox__subtitle">Benefits To You</h3>
                                                <div class="kt-infobox__content">
                                                    - Your Deals Reach More Than a Million Users & 10,000+ B2B Partners . <br>
                                                    - Targeted Audience , Rich Niche Travel Community .<br>
                                                    - Growing Traffic & Potential Customers <br>
                                                    - Fast & Easy Set up <br><br>
                                                    To Know PPC Ad Plans and More Contact Us Using Submission Form or Mail Us Directly at
                                                    <a href="" class="kt-link">sales@thetravelsquare.in</a>.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end:: Section -->
                        <!-- begin:: Section -->
                        <div class="kt-container ">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="kt-portlet kt-callout">
                                        <div class="kt-portlet__body">
                                            <div class="kt-callout__body">
                                                <div class="kt-callout__content">
                                                    <h3 class="kt-callout__title">Advertise On Our Platform</h3>
                                                    <p class="kt-callout__desc">
                                                        Send Us Your Request Here , Our Team Will Connect With You Shortly
                                                    </p>
                                                </div>
                                                <div class="kt-callout__action">
                                                    <a href="<?= base_url('partner-contact/ppc-request');?>" class="btn btn-custom btn-bold btn-upper btn-font-sm btn-dark">Submit Request</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="kt-portlet kt-callout">
                                        <div class="kt-portlet__body">
                                            <div class="kt-callout__body">
                                                <div class="kt-callout__content">
                                                    <h3 class="kt-callout__title">Get in Touch For Business</h3>
                                                    <p class="kt-callout__desc">
                                                        For Business & Investment Related Queries Contact With The Team Here
                                                    </p>
                                                </div>
                                                <div class="kt-callout__action">
                                                    <!-- <a href="<?= base_url('partner-contact/business-request');?>" data-toggle="modal" data-target="#kt_chat_modal" class="btn btn-custom btn-bold btn-upper btn-font-sm  btn-success">Submit Request</a> -->
                                                    <a href="<?= base_url('partner-contact/business-request');?>"  class="btn btn-custom btn-bold btn-upper btn-font-sm  btn-dark">Submit Request</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end:: Section -->
                        <!-- end:: Content -->				
                    </div>
                    <!-- begin:: Footer -->
                        <br><br>
                    <!-- end:: Footer -->			
                </div>
            </div>
        </div>
        <?php include('jquery.php');?>
    </body>
</html>