                    <div class="kt-footer  kt-grid__item kt-grid kt-grid--desktop kt-grid--ver-desktop" id="kt_footer">
                        <div class="kt-container  kt-container--fluid ">
                            <div class="kt-footer__copyright">
                                2022&nbsp;©&nbsp;<a href="http://partner.thetravelsquare.in/" target="_blank" class="kt-link"><font color="black"><b> Business Platform | The Travel Square</b></font></a>
                            </div>
                            <div class="kt-footer__menu">
                                <a href="http://about.thetravelsquare.in/" target="_blank" class="kt-footer__menu-link kt-link">About</a>
                                <a href="http://thetravelsquare.in/terms-and-conditions" target="_blank" class="kt-footer__menu-link kt-link">T&C</a>
                                <a href="http://thetravelsquare.in/privacy-policy" target="_blank" class="kt-footer__menu-link kt-link">Privacy Policy</a>
                                <a href="http://support.thetravelsquare.in/partnercare" target="_blank" class="kt-footer__menu-link kt-link">Partner Care</a>
                            </div>
                        </div>
                    </div>