<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    
	
	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-EE16CRYW41"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-EE16CRYW41');
</script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.js"></script>
    <link rel="stylesheet" type="text/css" href="slick/slick.css">
  <link rel="stylesheet" type="text/css" href="slick/slick-theme.css">
    <link rel="stylesheet" href="style.css">

   
  </head>
  <body>
		
       <header id="privacy-policy">
           <div class="dark-overlay">
               <div class="home-inner container">
                   <div class="row">
                       <div class="col-md-12">
                            <div class="text">
                                <center><h1><small>Privacy Policy</small></h1>
                                <p>The Travel Square App & Website</p></center>
                            </div>
                            
                       </div>
                   </div>
               </div>
           </div>
       </header>
		<br>
		
		
				 
				  <br>
				  
				  
	<div class="text-muted py-4 mb-2">
				  
				 
                <div class="container">
				<font color="black" style="font-family:verdana;">
				
				
				<h5>Welcome to The Travel Square</h5><br>
				<p>The Travel Square (TM) Hashtrek Travel Private Limited , Parent Company to The Travel Square, accessible from <a href="https://www.thetravelsquare.in/" target="_blank">
				https://www.thetravelsquare.in/</a> ,recognizes the importance of data privacy and respect the privacy of our user and visitors on all our platforms (channels).
				</p>
				<p>At The Travel Square one of our main priorities and concern is the privacy of our visitors and also of maintaining confidentiality of the information
				provided by its users as a responsible data controller and data processer. .</p>
				<br>
				<h5>Introdcution</h5>
				<p>
				The Travel Square Privacy Policy contains information about collecting user's , personal data, products and services offered or performed by The Travel Square 
				and the manner of its processing. We respect the right to privacy of our software users and take reasonable steps for the user to be familiar with the manner
				in which rendered accessible information via <a href="https://www.thetravelsquare.in/" target="_blank">https://www.thetravelsquare.in/</a> website, its sub-domains and the any application is processed. Due to the implementation
				of comprehensive security regulations, personal data provided by our website and application is of highest security standards. The acceptance of terms and 
				conditions for the use of any The Travel Square services or deciding on using or purchasing any product offered by The Travel Square means accepting The Travel
				Square Privacy Policy. For the purpose of this policy, unless otherwise specified, The Travel Square will also include The Travel Square website and all other
				propreitory associated websites/applications and include any 3rd party social media channels [like Facebook, Whatsapp] which may be used by The Travel Square
				from time to time to facilitate conversation or transactions between users.
				</p>
				<br>
	
				<h5>Scope</h5>
<p>This Privacy Policy provides for the practices for handling and securing user's Personal Information (defined hereunder) by The Travel Square and its subsidiaries and affiliates.This Privacy Policy is effective to all information collected by The Travel Square or The Travel Square  from which an individual can be identified (personal information/personal data).</p>

<hr>

<h5>Definitions</h5>
<p>For purposes of this Policy the following definitions shall apply: <br><br>
'<b>Personal information (personal data)</b>’ means any information or set of information that identifies or could be used by or on behalf of The Travel Square  to identify an individual, in particular name, surname, company business name, address, website address, e-mail address and credit/payment card information.<br><br>

<b>‘User’</b> or <b>‘Users’</b> means any customer of The Travel Square , who uses our software. <b>‘Agent’</b> means any third party that collects, process and/or uses personal information under the instruction of The Travel Square  ‘The Travel Square ’ means The Travel Square , its successors, subsidiaries, divisions and groups in any state of india , country in the world.<br><br>
This Privacy Policy is applicable to any person <b>(‘User’)</b> who purchase, intend to purchase, or inquire about any product(s) or service(s) made available by The Travel Square through any of The Travel Square's customer interface channels including its customer website, partner website, mobile site's, mobile apps & offline channels including call centers and offices (collectively referred herein as <b>"Sales Channels"</b>).</p>

<hr>

<h5>Notice</h5>
<p>In certain situations, we may be required to disclose personal data in response to lawful requests by public authorities, including to meet national security or law enforcement requirements. Please be aware we may disclose personal data to respond to subpoenas, court orders or legal process, or to establish or exercise our legal rights or defend against legal claims.</p>

<hr>

<h5>What Information Do We Collect</h5>
<h6>Provided Data</h6>
<p>The Travel Square’s main purpose of gathering personal data and user’s other information is to maintain service, ensure safe and guaranteed service performance for its users, upgrade and improve functionality of its services and products. Personal data and other user’ information collected by The Travel Square  is used in order to complete user registration and at the same time to ensure his access to The Travel Square ’s services and products. While registering on our website https://www.thetarvelsquare.in/ we request that you provide us with such information as: name, surname, company business name, address, website address, e-mail address and credit/payment card information in the event when a user continues to use our services after free of charge trial period. Unless a user decides to use our services after free of charge trial period, credit/payment card information is not required. We also collect personal data provided by users while using our services and programs. Some of the provided user’s information such as: your IP address, domain, browser type, operating system type etc. may be automatically acquired when a user visits our websites. When contacting The Travel Square  the user may be requested to render accessible analogical data to those provided while registering on our website. Personal data provided in connection with the correspondence between the user and The Travel Square  shall be used strictly to reply to inquiries made by the user or to transfer information. We use the information you provide us in order to provide you with customer service, allow you to view your reports, chats, chat logs, view the chat operators (persons you employ while using our software) and visitors to your The Travel Square  service. When using the support section of our site we may collect your e-mail address, name or openID account for the purpose of allowing contact with our support team. When using our software we may collect device information such as device type, operating system type and application version. We use this information in order to provide an optimized version of our application for your device type. Please be aware we also collect and process data related to the use of our software and services by our users and their customers. We use such data for statistics purposes. We may use it also to improve our software or create and improve new services. We collect and process such data collectively and anonymously.</p>

<h6>Geo-Location data</h6>
<p>Please be aware The Travel Square  may have access to your geo-location data as we collect and process IP address of all devices you use our software on. Collecting and processing your geo-location data refers to mobile devices as well as computers.</p>

<h6>Communications from the site</h6>
<p>If you choose to receive it, we will send you a ‘The Travel Square  daily summary’. This e-mail is provided as part of the service so that you may have a summary of your daily chat logs. You may opt-out from receiving this at any time by updating your preferences within your account. We will occasionally send you push notifications in order to make you aware of any outages of service or to send you ‘The Travel Square  daily summaries’ if you choose to receive them. You may opt-out of receiving these types of communications by turning off push notifications at the device level.We may also send you some e-mails from our blog (described more fully in Subsection J below). If you wish not to receive such notification you have an option to ‘unsubscribe’ this type of communication anytime. We will also send you notifications related to some important updates of our products. The purpose of sending you such e-mails or messages is to keep you informed of the latest improvements, features and other developments. From time to time we may also send you some other messages, notifications or text messages (both transactional and promotional SMS). Users who leave their contact details while accessing particular sections of our website (such as reports) might receive additional messages not described above.</p>

<h6>Third party personal data</h6>
<p>We allow you to provide us with third party personal data. The information that we may collect is name, surname, e-mail address and other contact information, in order to allow you to add operators (persons you employ while using our software) to your account and provide services to your visitors and/or clients. We will not use this information for any purpose which is not compliant with our Privacy Policy. Please be aware we also collect and process personal data such as: name, surname, e-mail address, and geo-location data of your visitors and persons you employ while using our software. We will not use this data for any purpose which is not compliant with our Privacy Policy. We may also collect other information (e.g., profile picture, network, username, user ID, age range, language, country) depending on your privacy settings. There are other instances where we may receive information from third parties.<br>
<ol class="list">
<li>a. You may separately provide registration and purchasing information to websites, apps, product or service providers through which we provide access to registration for our service. Depending on the particular promotion, when you register for the service through such a promotional partner of ours, that partner may provide us with a user/member name that you already use with that partner’s products or services or that you or it have otherwise pre-selected as part of the promotion. For example, when you use an external social network (like your Facebook account) to log in to the service or to interact with us in another way, we may collect your name and other details from your social network profile and account (please see your social network’s privacy policy or support documents for more information about their sharing of information with connected accounts).</li><br>
<li>b. As you are using our services, you may click through certain links or promotions that will enable you to purchase products or use services provided by promotional partners or other sites or commerce providers. Some of those entities may share with us certain information that you provide to them. By clicking through to those links or promotions, you agree to allow us to receive and use any information, except for credit card information (account number, expiration date) that you may provide to such entities, under the same terms as if you provided it to us directly.</li><br>
<li>c. You may also separately share your information with other sites or entities, such as those that create professional marketing lists, to receive special offers and promotions from its partners. These entities or sites may agree to share your information with us. Whether or not any third party actually shares your information and to what extent they do share with us will depend on their agreement with us and their individual privacy policy. The Travel Square  is not responsible and will assume no liability if another site or commerce provider collects, uses or shares, any information about you in violation of its own privacy policy, or applicable law.</li><br>
<li>d. We may purchase marketing data from third parties and add it to our existing user database, to better target our advertising and to provide pertinent offers in which we think you would be interested. To enrich our profiles of individual customers, we may tie this information to the personally identifiable information they have provided to us.</li><br>
</ol>
</p>

<h6>Data ‘cookies’ Policy</h6>
<p>The so called ‘cookies’ are used while using services or products rendered by The Travel Square  These are pieces of information sent by the server, stored on a user’s computer for the purpose of automatic identification of a particular user when using our services. ‘Cookies’ enable us to quickly confirm your identity and owing to them the use of our services becomes much easier and more widely available. ‘Cookies’ are used by The Travel Square  solely with the purpose of personalizing a particular user. ‘Cookies’ can be used on condition that they are accepted by a browser and that they shall not be removed from the storage media. Users who removed ‘cookies’ from their storage media or have not accepted them on their browser may not have access to products or services rendered by The Travel Square  We do not link the information we store in cookies to any personal data you submit while on our site. The use of third party cookies is not covered by our Privacy Policy. We do not have access or control over these cookies.</p>

<h6>Children's Information Policy</h6>
<p>Another part of our priority is adding protection for children while using the internet. We encourage parents and guardians to observe, participate in, and/or monitor and guide their online activity.The Travel Square does not knowingly collect any Personal Identifiable Information from children under the age of 13. If you think that your child provided this kind of information on our website, we strongly encourage you to contact us immediately and we will do our best efforts to promptly remove such information from our records.</p>

<h6>Mobile analytics</h6>
<p>We use mobile analytics software to allow us to better understand the functionality of our Mobile Software on your device. This software may record information such as how often you use the application, the events that occur within the application, aggregated usage, performance data, and where the application was downloaded from. We may link the information we store within the analytics software to personal data you submit within the application.</p>


<h6>Social media (Features) and Widgets</h6>
<p>Our website includes social media features, such as the ‘Facebook Like button’ and Widgets, such as the ‘Share This button’ or interactive mini-programs that run on our site. These features may collect your IP address, which page you are visiting on our site, and may set a cookie to enable the feature to function properly. Social media features and widgets are either hosted by a third party or hosted directly on our site. Your interactions with these features are governed by the privacy policy of the company providing it.</p>

<hr>

<h5>Data disclosure</h5>
<p>The Travel Square ’s main purpose of gathering personal data and users’ other information is to  maintain service, ensure safe and guaranteed service performance for its users, upgrade and improve functionality of its services and products. Owing to the above process we exceed our users’ expectations, we provide a constant development of our products the use of which becomes much easier and more convenient. In order to ensure orderly and safety functioning our service and products we use the software of other entities providing services (described below). The following are exceptions, with respect to whom we may share your personal information:
<ol>
<li>a. The Travel Square  reserves the right to disclose personal data to any of our parent, subsidiary, affiliated or successor companies.<li><br>
<li>b. The Travel Square  reserves the right to disclose personal data and other information relating to the user to third parties, persons or entities providing services to us or acting as our agents as part of our provision of the service (such as hosting, credit card processing, customer/support services, e-mail, text messages, push notifications providers or others). The Travel Square  shall observe due diligence to make sure for the processing of data disclosed to entities affiliated and associated with The Travel Square  to be in compliance with our Privacy Policy and the currently effective law.<li><br>
<li>c. Credit/payment card data provided by the user are disclosed solely to professional companies that conduct non-cash transactions and only to the extent necessary to effect the payments. Except for the above situations The Travel Square  shall not disclose any information or personal data provided by users.<li><br>
<li>d. Personal data can be disclosed to entities into which our company is merged, or to which our assets, site or operations have been transferred. Mentioned entities will be able to use your personal information under the terms of this Privacy Policy. We will notify you if any of these events occur by updating this Privacy Policy and, if practically possible, via other means.<li><br>
</ol>
Personal data and other information provided by users shall not be disclosed to third parties unless the obligation to disclose the information to third parties results from the currently effective provisions of law, such as to comply with a subpoena, or similar legal process, when we believe in good faith that disclosure is necessary to protect our rights, protect your safety or the safety of others, investigate fraud, or respond to a government request, or if it is necessary for the The Travel Square ’s security and its rights protection, including the protection against the claims submitted by the third parties. The provided user’s information may be utilized in the event of breach of terms and conditions for the use of services, misuse of funds, the necessity to take action against all user’s unlawful actions. The Travel Square  shall transfer no information or personal data to third parties for marketing purposes. The Travel Square  reserves the right to use the provided data for the marketing purposes and other purposes connected with presenting up-to-date offer of products and services in direct contacts with the user. You may opt-out from our marketing e-mails at any time by following the unsubscribe instructions located at the bottom of each communication or by e-mailing us at <font color="sky-blue"><a href="mailto:info@thetravelsquare.in">info@thetravelsquare.in</a></font> .
</p>

<hr>

<h5>Accountability for Onward Transfer</h5>
<p>We will not transfer your personal data originating in the EU and Switzerland to third parties unless we ensure such third parties is obliged to provide at least the same level of privacy protection to your personal data as required by the Principles of the EU-U.S.</p>

<hr>

<h5>Safety & Security</h5>
<p>We guarantee that we take reasonable and appropriate technical and operational measures to protect your personal information we collect and hold from loss, misuse and unauthorized access, disclosure, alteration, and destruction. While protecting your personal data we take into due account the risk involved in the processing and the nature of the personal data.</p>

<hr>

<h5>User generated content</h5>
<p>The Travel Square will have unrestricted access to use, modify, recreate or as maybe required from time to time any part of user generated content being created, generated, published, shared by the users on its website or The Travel Square controlled or moderated or administrated 3rd party social media applications like Facebook, WhatsApp. The Travel Square has the right to distribute, publish, recreate, modify and use the user generated content across the website and 3rd party social media applications. The Travel Square also reserves the right to market this content it may deem fit for its own advertisement purposes.The Travel Square will not share any personal confidential financial information like credit card details on its platform publicly or sell them to a third party.</p>

<hr>

<h5>Access</h5>
<p>If you wish to access, amend, or confirm that The Travel Square  has personal data relating to you, or if you wish to correct or delete your personal information if it is inaccurate, please notify us at: <font color="sky-blue"><a href="mailto:info@thetravelsquare.in">info@thetravelsquare.in</a></font>. We will respond to your access request within 30 days. To request removal of your personal data from our testimonials or customer support forum, please contact us at <font color="sky-blue"><a href="mailto:info@thetravelsquare.in">info@thetravelsquare.in</a></font>. In some cases, we may not be able to remove your personal information, in which case we will let you know if we are unable to do so and why.</p>

<hr>

<h5>Recourse, Enforcement and Liability</h5>
<p>Since we are committed to protecting your privacy as set forth in this Policy, if you think we are not in compliance with our Policy, or if you have any question or if you wish to take any other action concerning this Policy or your personal information, we encourage you to contact us. We will investigate your complaint, take appropriate action and report back to you within 10 days</p>

<hr>

<h5>Surveys</h5>
<p>From time-to-time we may provide you the opportunity to participate in a survey within our The Travel Square  application or via e-mail. If you participate, we may require your name and e-mail address. Participation in these surveys is completely voluntary and you therefore have a choice whether or not to disclose this information.</p>

<hr>

<h5>Add-ons</h5>
<p>We allow you the option to integrate your live chat with third party add-ons. Please be aware that The Travel Square  is not responsible for any information that may collected through these third party add-ons</p>

<hr>

<h5>Data protection</h5>
<p>The Travel Square  applies technical safety measures of the highest standards to protect the provided personal data against loss, destruction, misuse, unauthorized access or disclosure. The used measures and technology ensure complete safety of the personal data provided by the user. The personal data is available solely to the user or to a person indicated by him provided authorized access has been granted to that person. You control who you allow access to the The Travel Square  app by either selecting everyone or limited IP addresses. The security of your personal data is important to us. We follow generally accepted industry standards to protect the personal data submitted to us, both during transmission and once we receive it. No method of transmission over the Internet, or method of electronic storage, is 100% secure, however. Therefore, we cannot guarantee its absolute security. The Travel Square  takes all necessary steps to update and modernize data protection system. No data transmission via the Internet, however, can guarantee 100% safety. When you enter sensitive information (such as credit card number) on our website or within our applications, we encrypt the transmission of that information using secure socket layer technology (SSL).</p>

<hr>

<h5>Privacy policy modification</h5>
<p>We may update this privacy statement to reflect changes to our information practices. If we make any material changes we will notify you by e-mail (sent to the e-mail address specified in your ‘owner’s account’) or by means of a notice on this Site prior to the change becoming effective. We encourage you to periodically review this page for the latest information on our privacy practices.</p>

<hr>

<h5>Commercial transactions</h5>
<p>The Travel Square  reserves the right to use its Privacy Policy, user’s account and provided data and information for the benefit of an entity that has become either a dependent entity, an associated entity, or has come into being as a result of merger or transformation of The Travel Square</p>

<hr>

<h5>Testimonials</h5>
<p>We post customer testimonials on our website which may contain personal data. We use the ‘Twitter social plugin’ to display our customers’ comments on our website. In any other scenario we do obtain the customer’s consent via e-mail prior to posting the testimonial to post their name along with their testimonial.</p>

<hr>

<h5>Community Chat forum</h5>
<p>Our website may offers publicly accessible chat forums which are visible to all those on our platform. You should be aware that any information you provide in these areas may be read, collected, and used by others who access them.</p>

<h5>Link to Other Sites</h5>
<p>The Travel Square ’s website contains links to other sites that are not owned or controlled by us. Please be aware that we are not responsible for the privacy practices of such other sites. We encourage you to be aware when you leave our site and to read the privacy policies of each and every website that collects personal data. This Privacy Policy applies only to information collected by The Travel Square</p>

<hr>

<h5>Log Files</h5>
<p>The Travel Square follows a standard procedure of using log files. These files log visitors when they visit websites. All hosting companies do this and a part of hosting services' analytics. The information collected by log files include internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages, and possibly the number of clicks. These are not linked to any information that is personally identifiable. The purpose of the information is for analyzing trends, administering the site, tracking users' movement on the website, and gathering demographic information.</p>

<hr>

<h5>Cookies and Web Beacons</h5>

<p>Like any other website, The Travel Square uses 'cookies'. These cookies are used to store information including visitors' preferences, and the pages on the website that the visitor accessed or visited. The information is used to optimize the users' experience by customizing our web page content based on visitors' browser type and/or other information.</p>

<hr>

<h5>Google DoubleClick DART Cookie</h5>

<p>Google is one of a third-party vendor on our site. It also uses cookies, known as DART cookies, to serve ads to our site visitors based upon their visit to www.website.com and other sites on the internet. However, visitors may choose to decline the use of DART cookies by visiting the Google ad and content network Privacy Policy at the following URL – <font color="sky-blue"><a href="https://policies.google.com/technologies/ads">https://policies.google.com/technologies/ads</a></font></p>

<hr>

<h5>Our Advertising Partners</h5>

<p>Some of advertisers on our site may use cookies and web beacons. Our advertising partners are listed below. Each of our advertising partners has their own Privacy Policy for their policies on user data. For easier access, we hyperlinked to their Privacy Policies below.</p>

<ul>
    <li>
        <p></p>
        <p>Google - <font color="sky-blue"><a href="https://policies.google.com/technologies/ads">https://policies.google.com/technologies/ads</a></font></p>
    </li>
</ul>

<hr>

<h5>Partners Ad Privacy Policies</h5>

<p>Third-party ad servers or ad networks uses technologies like cookies, JavaScript, or Web Beacons that are used in their respective advertisements and links that appear on The Travel Square, which are sent directly to users' browser. They automatically receive your IP address when this occurs. These technologies are used to measure the effectiveness of their advertising campaigns and/or to personalize the advertising content that you see on websites that you visit.</p>

<p>Note that The Travel Square has no access to or control over these cookies that are used by third-party advertisers.</p>

<hr>

<h5>Third Party Ad Privacy Policies</h5>

<p>The Travel Square's Privacy Policy does not apply to other advertisers or websites. Thus, we are advising you to consult the respective Privacy Policies of these third-party ad servers for more detailed information. It may include their practices and instructions about how to opt-out of certain options. You may find a complete list of these Privacy Policies and their links here: Privacy Policy Links.</p>

<p>You can choose to disable cookies through your individual browser options. To know more detailed information about cookie management with specific web browsers, it can be found at the browsers' respective websites.</p>

<hr>

<h5>Consent</h5>

<p>By using our website, you hereby consent to our Privacy Policy and agree to its <font color="sky-blue"><a href="https://www.thetravelsquare.in/termsandconditions" target=""_blank><u>Terms and Conditions.</u></a></font></p>

<hr>

<h5>FAQ's & concerns</h5>

<p>If you have any questions or concerns, or if you wish to update, delete, or change any personal information we hold, please contact us at <font color="sky-blue"><a href="mailto:info@thetravelsquare.in">info@thetravelsquare.in</a></font></p>

<hr>

<h5>Contact</h5>
<p>Should you have any inquiries or doubts regarding our Privacy Policy or applied procedures feel free to contact us via the following e-mail: <font color="sky-blue"><a href="">

<font color="sky-blue"><a href="mailto:info@thetravelsquare.in">info@thetravelsquare.in</a></font></a> .</p>	</font>


</font>
		   
				
                </div>
        </div>
		

   

     

     <footer class="footer bg-black py-5">
        <div class="container">
            <div class="row">
				<div class="offset-md-2 col-md-4"><br>
                    <a href="http://business.thetravelsquare.in/" target="_blank">
					<img style="width: 65%; height: 97px;" src="./img/the-travel-square-indias-largest-b2b-travel-network.png" alt="the-trave-square-logo" class="img-fluid mx-auto d-block">
					</a>
                </div>
                <div class="col-md-6"><br><br>
                   <font size="2" color="white"><h5>India's Largest Travel Network</h5>
				    <p>
					Our Smart Technology Driven AI Platform Enables The Customers to Explore Places , Select There Priorities While Travelling, 
					Building creative Itineraries Following their Tastes and likkings at best possible rates, Enabling them to compare prices intelligently Saving Time and Effort , ensuring complete satisfaction and service for their vacations and business trips .

					</p>
				   </font>
				</div>
                
            </div>
            <hr color="white">
			<font size="2">
            
			
            
            <div class="container py-4">
                <div class="row">
					<div class="col-md-3">
                        
                        <div class=""><small><center>
                           <a class="text-light" href="https://www.facebook.com/thetravelsquareb2b" target="_blank" rel=”nofollow”><i class="fa fa-facebook fa-2x ml-3"></i></a>
                           <a class="text-light" href="https://twitter.com/travelsquareb2b" target="_blank" rel=”nofollow”><i class="fa fa-twitter fa-2x ml-3"></i></a>
                           <a class="text-light" href="https://www.instagram.com/thetravelsquareofficial/" target="_blank" rel=”nofollow”><i class="fa fa-instagram fa-2x ml-3"></i></a>
                           <a class="text-light" href="https://www.linkedin.com/company/thetravelsquareb2b" target="_blank" rel=”nofollow”><i class="fa fa-linkedin fa-2x ml-3"></i></a>
                           <a class="text-light" href="https://www.linkedin.com/company/thetravelsquareb2b" target="_blank" rel=”nofollow”><i class="fa fa-youtube fa-2x ml-3"></i></a>
                           </small></center>
						  <br>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <center>
						
                        <i class="fa fa-phone text-muted mb-2"></i> &nbsp; <a href="tel:9999007037"><font color="white">+91-8595-9027-52 | 11-406-401-87</font></a>
						</center>
					</div>
                    <div class="col-md-3">
						<center>
                        
                        <i class="fa fa-envelope text-muted mb-2"></i> &nbsp;<a href="mailto:info@thetravelsquare.in"><font color="white">info@thetravelsquare.in</font></a
						</center>
                    </div>
                    
					<div class="col-md-3">
						<center>
                        <p class="text-muted mt-2">
							
                               <a href="http://www.thetravelsquare.in/"><font color="white" ><big>The Travel Square</big></a> <br><small>&copy; 2022 All Rights Reserved <br></small>
                               </font>
						</center>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>


  </body>
</html>
