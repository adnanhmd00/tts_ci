-- MySQL dump 10.13  Distrib 8.0.22, for Linux (x86_64)
--
-- Host: localhost    Database: oregonix_ts
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `emi_application`
--

DROP TABLE IF EXISTS `emi_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emi_application` (
  `id` int NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `date_birth` varchar(255) NOT NULL,
  `month_birth` varchar(255) NOT NULL,
  `year_birth` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `home_address` varchar(255) NOT NULL,
  `landmark` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `employment_type` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `year_in_service` varchar(255) NOT NULL,
  `ofc_city` varchar(255) NOT NULL,
  `ofc_address` varchar(255) NOT NULL,
  `adhar_front` varchar(255) NOT NULL,
  `adhar_back` varchar(255) NOT NULL,
  `photograph` varchar(255) NOT NULL,
  `elec_bill` varchar(255) NOT NULL,
  `pancard` varchar(255) NOT NULL,
  `cancelled_checque` varchar(255) NOT NULL,
  `departure_ticket` varchar(255) DEFAULT NULL,
  `return_ticket` varchar(255) NOT NULL,
  `passbook_last_page` varchar(255) NOT NULL,
  `hotel_booking_voucher` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `ac_holder` varchar(255) NOT NULL,
  `ifsc` varchar(255) NOT NULL,
  `ac_num` varchar(255) NOT NULL,
  `origin` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emi_application`
--

LOCK TABLES `emi_application` WRITE;
/*!40000 ALTER TABLE `emi_application` DISABLE KEYS */;
INSERT INTO `emi_application` VALUES (1,'Adnan','Sidd','17','10','1994','male','India','Bihar','jkl','Near Factoty','adnanhmd00@gmail.com','7701853375','Nothing','TTS','1','Delhi','Gr. Noida','61070685','456789123','123456789','510706850731','GAJPS7126C','NOPE','159753','147852369','145236','147852369','SBI','Adnan','SBIN0012554','34669238487','customer'),(1,'Adnan','Sidd','17','10','1994','male','India','Bihar','jkl','Near Factoty','adnanhmd00@gmail.com','7701853375','Nothing','TTS','1','Delhi','Gr. Noida','61070685','456789123','123456789','510706850731','GAJPS7126C','NOPE','159753','147852369','145236','147852369','SBI','Adnan','SBIN0012554','34669238487','customer');
/*!40000 ALTER TABLE `emi_application` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-02 15:49:38
