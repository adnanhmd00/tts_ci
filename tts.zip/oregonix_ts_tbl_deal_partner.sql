-- MySQL dump 10.13  Distrib 8.0.22, for Linux (x86_64)
--
-- Host: localhost    Database: oregonix_ts
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_deal_partner`
--

DROP TABLE IF EXISTS `tbl_deal_partner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_deal_partner` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_tag` varchar(10) DEFAULT NULL,
  `partner_id` varchar(10) NOT NULL,
  `deal_type_id` varchar(10) NOT NULL,
  `title` text NOT NULL,
  `currency_id` varchar(10) NOT NULL,
  `new_price` varchar(10) NOT NULL COMMENT 'b2b price',
  `old_price` varchar(10) DEFAULT NULL COMMENT 'b2c price',
  `noofdays` varchar(10) NOT NULL,
  `noofnights` varchar(10) NOT NULL,
  `tac` varchar(10) NOT NULL,
  `unit_type` enum('Per Person','Per Night') NOT NULL,
  `details` text NOT NULL,
  `cancelation_policy` text,
  `dates_of_travel` date NOT NULL,
  `destination` text NOT NULL,
  `valid_untill` date NOT NULL,
  `hotel_name_room_meal` text,
  `flight_trip_type` enum('One Way','Round Trip') DEFAULT NULL,
  `package_type` enum('Fixed Departure','Customised','Regular') DEFAULT NULL,
  `inclusion` enum('Flights','Transfer','Visa','Hotels','Sightseeing') DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `is_verified` enum('YES') DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_deal_partner`
--

LOCK TABLES `tbl_deal_partner` WRITE;
/*!40000 ALTER TABLE `tbl_deal_partner` DISABLE KEYS */;
INSERT INTO `tbl_deal_partner` VALUES (16,NULL,'1','2','shaun','1','1478','1000','','','5','Per Night','<p>shaun</p>','<p>shaun</p>','0000-00-00','mamali','2020-10-10',NULL,'One Way',NULL,NULL,'approved',NULL,'2020-04-23 10:48:44','2020-04-25 20:35:10','2020-04-25 21:25:21'),(17,NULL,'1','6','shaun','2','1336','1206','5','4','5','Per Night','shaun','shaun','0000-00-00','mamali','2020-04-18',NULL,NULL,NULL,NULL,'approved',NULL,'2020-04-23 11:15:22','2020-04-23 11:15:22',NULL),(18,NULL,'1','1','shaun Test edit','1','1500','1400','2','1','5','Per Person','<p>Shaun</p>','<p>Shaun Frost</p>','0000-00-00','mamali','2020-05-13',NULL,NULL,'Customised',NULL,'pending',NULL,'2020-04-25 21:04:38','2020-06-15 14:34:38',NULL);
/*!40000 ALTER TABLE `tbl_deal_partner` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-02 15:49:31
