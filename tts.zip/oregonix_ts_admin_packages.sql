-- MySQL dump 10.13  Distrib 8.0.22, for Linux (x86_64)
--
-- Host: localhost    Database: oregonix_ts
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_packages`
--

DROP TABLE IF EXISTS `admin_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_packages` (
  `id` int NOT NULL,
  `supplier_id` varchar(255) DEFAULT NULL,
  `package_id` varchar(255) DEFAULT NULL,
  `pkg_name` varchar(255) NOT NULL,
  `pkg_img` varchar(255) NOT NULL,
  `city_to` varchar(255) NOT NULL,
  `city_from` varchar(255) NOT NULL,
  `num_nights` varchar(255) NOT NULL,
  `num_days` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `ex_covered` varchar(255) NOT NULL,
  `exp_date` varchar(255) NOT NULL,
  `inclusion` varchar(255) NOT NULL,
  `descrip` varchar(255) NOT NULL,
  `t_c` varchar(255) NOT NULL,
  `pkg_price` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_packages`
--

LOCK TABLES `admin_packages` WRITE;
/*!40000 ALTER TABLE `admin_packages` DISABLE KEYS */;
INSERT INTO `admin_packages` VALUES (1,'','TTSS0001','net check','adnan-siddique-the-travel-square.png','1','1','10','10','1','1','1','1','1','1','1000'),(2,'','TTSS0002','net check','adnan-siddique-the-travel-square.png','2','22','20','20','2','2','2','2','12','12','22000'),(3,'TTSS0004','TTSS0003','1','DSC_0121-01.jpeg','1','1','31','31','1','1','01/07/2020','1','1','1','5000'),(4,'TTSS0004','TTSS0004','1','DSC_0121-01.jpeg','1','1','10','10','1','1','1','1','1','1','1100'),(5,'TTSS00015','TTSS0005','1','DSC_0121-01.jpeg','1','1','10','10','1','1','1','1','1','1','1700'),(6,'','TTSS0006','net check','DSC_0121-01.jpeg','5','5','12','01','5','5','03/01/2020','5','5','5\r\n','500'),(7,'','TTSS0007','now','DSC_0099-02.jpeg','now','now','01','01','now','now','03/01/2020','now','now','nwo','5000'),(8,'TTSS0004','TTSS0008','net check','adnan-siddique-the-travel-square.png','New Delhi','New Delhi','14','04','New Delhi','k','03/16/2020','bjk','lj','lj','1550'),(9,'TTSS00015','TTSS0009','package_id','adnan-siddique-the-travel-square.png','package_id','package_id','01','02','package_id','package_id','03/02/2020','package_id','package_id','package_id','7000'),(10,'4','TTSS0010','4','DSC_0104-01.jpeg','4','4','02','02','4','4','03/02/2020','4','4','4','2000'),(1,'','TTSS0001','net check','adnan-siddique-the-travel-square.png','1','1','10','10','1','1','1','1','1','1','1000'),(2,'','TTSS0002','net check','adnan-siddique-the-travel-square.png','2','22','20','20','2','2','2','2','12','12','22000'),(3,'TTSS0004','TTSS0003','1','DSC_0121-01.jpeg','1','1','31','31','1','1','01/07/2020','1','1','1','5000'),(4,'TTSS0004','TTSS0004','1','DSC_0121-01.jpeg','1','1','10','10','1','1','1','1','1','1','1100'),(5,'TTSS00015','TTSS0005','1','DSC_0121-01.jpeg','1','1','10','10','1','1','1','1','1','1','1700'),(6,'','TTSS0006','net check','DSC_0121-01.jpeg','5','5','12','01','5','5','03/01/2020','5','5','5\r\n','500'),(7,'','TTSS0007','now','DSC_0099-02.jpeg','now','now','01','01','now','now','03/01/2020','now','now','nwo','5000'),(8,'TTSS0004','TTSS0008','net check','adnan-siddique-the-travel-square.png','New Delhi','New Delhi','14','04','New Delhi','k','03/16/2020','bjk','lj','lj','1550'),(9,'TTSS00015','TTSS0009','package_id','adnan-siddique-the-travel-square.png','package_id','package_id','01','02','package_id','package_id','03/02/2020','package_id','package_id','package_id','7000'),(10,'4','TTSS0010','4','DSC_0104-01.jpeg','4','4','02','02','4','4','03/02/2020','4','4','4','2000');
/*!40000 ALTER TABLE `admin_packages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-02 15:49:30
