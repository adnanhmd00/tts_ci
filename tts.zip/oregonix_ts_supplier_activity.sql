-- MySQL dump 10.13  Distrib 8.0.22, for Linux (x86_64)
--
-- Host: localhost    Database: oregonix_ts
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `supplier_activity`
--

DROP TABLE IF EXISTS `supplier_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_activity` (
  `id` int NOT NULL AUTO_INCREMENT,
  `supplier_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `descrip` varchar(255) NOT NULL,
  `from_time` varchar(255) NOT NULL,
  `to_time` varchar(255) NOT NULL,
  `types` varchar(255) NOT NULL,
  `cost` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_activity`
--

LOCK TABLES `supplier_activity` WRITE;
/*!40000 ALTER TABLE `supplier_activity` DISABLE KEYS */;
INSERT INTO `supplier_activity` VALUES (1,'','API Check','API Check','API Check','API Check','API Check','API Check','API Check'),(2,'','API Check','API Check','API Check','API Check','API Check','API Check','API Check'),(3,'','angular','angular','angular','angular','angular','Private','anglar'),(4,'','test','test','test','test','test','Private','test'),(5,'','check','check','check','check','check','Private','check'),(6,'','47','47','7','8','88','Private','8'),(7,'','Ryewood Green','1','fsf','1','1','SIC','1'),(8,'','Ryewood Green','1','fsf','1','1','SIC',''),(9,'','adnan','http://image.com','andann','djfall','kljldjlj','Private','jlkjajldj'),(10,'','form','http://image.com','expendjf','ajfdaj','jdlkafj','SIC','kdjf'),(11,'','form','http://image.com','expendjf','ajfdaj','jdlkafj','Private','kdjf'),(12,'TTSS00015','Ryewood Green','http://image.com','expendjf','ajfdaj','1','SIC','1000'),(13,'TTSS00016','Ryewood Green','http://image.com','expendjf','ajfdaj','jdlkafj','Private','123');
/*!40000 ALTER TABLE `supplier_activity` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-02 15:49:35
