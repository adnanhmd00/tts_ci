-- MySQL dump 10.13  Distrib 8.0.22, for Linux (x86_64)
--
-- Host: localhost    Database: oregonix_ts
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `holiday_cities`
--

DROP TABLE IF EXISTS `holiday_cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `holiday_cities` (
  `id` int NOT NULL,
  `city` varchar(255) NOT NULL,
  `links` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holiday_cities`
--

LOCK TABLES `holiday_cities` WRITE;
/*!40000 ALTER TABLE `holiday_cities` DISABLE KEYS */;
INSERT INTO `holiday_cities` VALUES (1,'Dubai','http://thetravelsquare.info/holiday/dubai.html'),(2,'Bali','http://thetravelsquare.info/holiday/bali.html'),(3,'Goa','http://thetravelsquare.info/holiday/goa.html'),(4,'Mauritius','http://thetravelsquare.info/holiday/mauritius.html'),(5,'Malaysia','http://thetravelsquare.info/holiday/malaysai.html'),(6,'Singapore','http://thetravelsquare.info/holiday/singapore.html'),(7,'Andaman','http://thetravelsquare.info/holiday/andaman.html'),(8,'Maldives','http://thetravelsquare.info/holiday/maldives.html'),(9,'Kerala','http://thetravelsquare.info/holiday/kerala.html'),(10,'Bangkok/Pattaya','http://thetravelsquare.info/holiday/bangkok-pattaya.html'),(11,'Vietnam','http://thetravelsquare.info/holiday/vietnam.html'),(12,'Udaipur','http://thetravelsquare.info/holiday/udaipur.html'),(13,'Jaipur','http://thetravelsquare.info/holiday/jaipur.html'),(14,'Agra','http://thetravelsquare.info/holiday/agra.html'),(15,'Delhi','http://thetravelsquare.info/holiday/delhi.html'),(16,'Varanasi','http://thetravelsquare.info/holiday/varanasi.html'),(17,'Mumbai','http://thetravelsquare.info/holiday/mumbai.html'),(18,'Manali','http://thetravelsquare.info/holiday/manali.html'),(19,'Shimla','http://thetravelsquare.info/holiday/shimla.html'),(20,'Mussorie','http://thetravelsquare.info/holiday/mussorie.html'),(21,'Jodhpur','http://thetravelsquare.info/holiday/jodhpur.html'),(22,'Jaisalmer','http://thetravelsquare.info/holiday/jaisalmer.html'),(23,'Kochi','http://thetravelsquare.info/holiday/kochi.html'),(24,'Munnar','http://thetravelsquare.info/holiday/munnar.html'),(25,'Allepey','http://thetravelsquare.info/holiday/allepey.html'),(26,'Gangtok','http://thetravelsquare.info/holiday/gantok.html'),(27,'Shillong','http://thetravelsquare.info/holiday/shillong.html'),(28,'Ranthambore','http://thetravelsquare.info/holiday/ranthambore.html'),(29,'Leh','http://thetravelsquare.info/holiday/leh.html'),(30,'Kaziranga','http://thetravelsquare.info/holiday/kaziranga.html'),(31,'Corbett','http://thetravelsquare.info/holiday/corbett.html'),(32,'Khajuraha','http://thetravelsquare.info/holiday/khajuraho.html'),(33,'Dharamshala','http://thetravelsquare.info/holiday/dharamshala.html'),(34,'Kolkata','http://thetravelsquare.info/holiday/kolkata.html'),(35,'Rishikesh','http://thetravelsquare.info/holiday/Rishikesh.html'),(36,'Darjeeling','http://thetravelsquare.info/holiday/darjeeling.html'),(37,'Fatehpur Sikhri','http://thetravelsquare.info/holiday/fatepursikhri.html'),(38,'Chennai','http://thetravelsquare.info/holiday/chennai.html'),(39,'Bangalore','http://thetravelsquare.info/holiday/banglore.html'),(40,'Kovalam','http://thetravelsquare.info/holiday/koavlam.html'),(41,'Pushkar','http://thetravelsquare.info/holiday/pushkar.html'),(42,'Hampi','http://thetravelsquare.info/holiday/hampi.html'),(43,'Amritsar','http://thetravelsquare.info/holiday/amritsar.html'),(44,'Coorg','http://thetravelsquare.info/holiday/coorg.html'),(1,'Dubai','http://thetravelsquare.info/holiday/dubai.html'),(2,'Bali','http://thetravelsquare.info/holiday/bali.html'),(3,'Goa','http://thetravelsquare.info/holiday/goa.html'),(4,'Mauritius','http://thetravelsquare.info/holiday/mauritius.html'),(5,'Malaysia','http://thetravelsquare.info/holiday/malaysai.html'),(6,'Singapore','http://thetravelsquare.info/holiday/singapore.html'),(7,'Andaman','http://thetravelsquare.info/holiday/andaman.html'),(8,'Maldives','http://thetravelsquare.info/holiday/maldives.html'),(9,'Kerala','http://thetravelsquare.info/holiday/kerala.html'),(10,'Bangkok/Pattaya','http://thetravelsquare.info/holiday/bangkok-pattaya.html'),(11,'Vietnam','http://thetravelsquare.info/holiday/vietnam.html'),(12,'Udaipur','http://thetravelsquare.info/holiday/udaipur.html'),(13,'Jaipur','http://thetravelsquare.info/holiday/jaipur.html'),(14,'Agra','http://thetravelsquare.info/holiday/agra.html'),(15,'Delhi','http://thetravelsquare.info/holiday/delhi.html'),(16,'Varanasi','http://thetravelsquare.info/holiday/varanasi.html'),(17,'Mumbai','http://thetravelsquare.info/holiday/mumbai.html'),(18,'Manali','http://thetravelsquare.info/holiday/manali.html'),(19,'Shimla','http://thetravelsquare.info/holiday/shimla.html'),(20,'Mussorie','http://thetravelsquare.info/holiday/mussorie.html'),(21,'Jodhpur','http://thetravelsquare.info/holiday/jodhpur.html'),(22,'Jaisalmer','http://thetravelsquare.info/holiday/jaisalmer.html'),(23,'Kochi','http://thetravelsquare.info/holiday/kochi.html'),(24,'Munnar','http://thetravelsquare.info/holiday/munnar.html'),(25,'Allepey','http://thetravelsquare.info/holiday/allepey.html'),(26,'Gangtok','http://thetravelsquare.info/holiday/gantok.html'),(27,'Shillong','http://thetravelsquare.info/holiday/shillong.html'),(28,'Ranthambore','http://thetravelsquare.info/holiday/ranthambore.html'),(29,'Leh','http://thetravelsquare.info/holiday/leh.html'),(30,'Kaziranga','http://thetravelsquare.info/holiday/kaziranga.html'),(31,'Corbett','http://thetravelsquare.info/holiday/corbett.html'),(32,'Khajuraha','http://thetravelsquare.info/holiday/khajuraho.html'),(33,'Dharamshala','http://thetravelsquare.info/holiday/dharamshala.html'),(34,'Kolkata','http://thetravelsquare.info/holiday/kolkata.html'),(35,'Rishikesh','http://thetravelsquare.info/holiday/Rishikesh.html'),(36,'Darjeeling','http://thetravelsquare.info/holiday/darjeeling.html'),(37,'Fatehpur Sikhri','http://thetravelsquare.info/holiday/fatepursikhri.html'),(38,'Chennai','http://thetravelsquare.info/holiday/chennai.html'),(39,'Bangalore','http://thetravelsquare.info/holiday/banglore.html'),(40,'Kovalam','http://thetravelsquare.info/holiday/koavlam.html'),(41,'Pushkar','http://thetravelsquare.info/holiday/pushkar.html'),(42,'Hampi','http://thetravelsquare.info/holiday/hampi.html'),(43,'Amritsar','http://thetravelsquare.info/holiday/amritsar.html'),(44,'Coorg','http://thetravelsquare.info/holiday/coorg.html');
/*!40000 ALTER TABLE `holiday_cities` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-02 15:49:34
