-- MySQL dump 10.13  Distrib 8.0.22, for Linux (x86_64)
--
-- Host: localhost    Database: oregonix_ts
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `stime` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (5,'Anshul','1234567890','12345','2019-05-26'),(6,'Ram Kumar','8178116791','12345','2019-06-04'),(7,'Vibhu','8178116792','12345','2019-06-04'),(8,'vibhu','8700571934','9818b65xz1','2019-06-05'),(9,'Vibhu','9654134201','9818b65xzm1','2019-06-05'),(10,'Yash Sharma','8510979572','988','2019-06-06'),(11,'Ishan Waghraje','9205848621','ishan','2019-06-06'),(12,'Prashant Sharma','7867899078','gfhjjk','2019-06-10'),(13,'Prashant Sharma','8882998124','vibhu','2019-06-10'),(14,'Adnan Siddique','7701853375','adnan','2019-06-11'),(15,'Ramu','8178116794','12345','2019-06-14'),(16,'Aditya Sharma','9650333567','facebookpas','2019-06-17'),(17,'Adnan Sidd','8804327704','adnan','2019-06-18'),(18,'Kunal Aggarwal','9811080535','facebookpas','2019-06-27'),(19,'adi','9876543210','0987654321','2019-07-08'),(5,'Anshul','1234567890','12345','2019-05-26'),(6,'Ram Kumar','8178116791','12345','2019-06-04'),(7,'Vibhu','8178116792','12345','2019-06-04'),(8,'vibhu','8700571934','9818b65xz1','2019-06-05'),(9,'Vibhu','9654134201','9818b65xzm1','2019-06-05'),(10,'Yash Sharma','8510979572','988','2019-06-06'),(11,'Ishan Waghraje','9205848621','ishan','2019-06-06'),(12,'Prashant Sharma','7867899078','gfhjjk','2019-06-10'),(13,'Prashant Sharma','8882998124','vibhu','2019-06-10'),(14,'Adnan Siddique','7701853375','adnan','2019-06-11'),(15,'Ramu','8178116794','12345','2019-06-14'),(16,'Aditya Sharma','9650333567','facebookpas','2019-06-17'),(17,'Adnan Sidd','8804327704','adnan','2019-06-18'),(18,'Kunal Aggarwal','9811080535','facebookpas','2019-06-27'),(19,'adi','9876543210','0987654321','2019-07-08');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-02 15:49:40
