-- MySQL dump 10.13  Distrib 8.0.22, for Linux (x86_64)
--
-- Host: localhost    Database: oregonix_ts
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `packages_booking`
--

DROP TABLE IF EXISTS `packages_booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `packages_booking` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL,
  `adults` varchar(255) NOT NULL,
  `child` varchar(255) NOT NULL,
  `coupon_code` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages_booking`
--

LOCK TABLES `packages_booking` WRITE;
/*!40000 ALTER TABLE `packages_booking` DISABLE KEYS */;
INSERT INTO `packages_booking` VALUES (1,'','','','','','','','',''),(2,'Adnan','Siddique','7701853375','adnansiddique620@gmail.com','11/30/2019','11/30/2019','3','3',''),(3,'Adnan','Siddique','12345678','adnansiddique620@gmail.com','11/30/2019','','Select','Select',''),(4,'Adnan','Siddique','12345678','adnansiddique620@gmail.com','11/30/2019','','Select','Select',''),(5,'Adnan','Siddique','7701853375','adnansiddique620@gmail.com','11/30/2019','11/30/2019','Select','Select',''),(6,'Adnan','Siddique','7701853375','adnansiddique620@gmail.com','11/30/2019','11/30/2019','Select','Select',''),(7,'Adnan','Siddique','12345','adnansiddique620@gmail.com','11/30/2019','11/30/2019','Select','Select',''),(8,'Adnan','Siddique','12','adnansiddique620@gmail.com','11/30/2019','11/30/2019','2','0',''),(9,'Adnan','Siddique','121345','adnansiddique620@gmail.com','11/30/2019','11/30/2019','2','0',''),(10,'Adnan','Siddique','12','adnansiddique620@gmail.com','11/30/2019','11/30/2019','4','1',''),(11,'Web','Check','147852369','webcheck@gmail.com','11/30/2019','11/30/2019','4','2',''),(12,'Vibhu','Gupta','08700571934','myworkspacevibhu@gmail.com','12/07/2019','12/08/2019','2','1','');
/*!40000 ALTER TABLE `packages_booking` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-02 15:49:32
