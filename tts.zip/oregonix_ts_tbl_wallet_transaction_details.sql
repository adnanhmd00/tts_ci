-- MySQL dump 10.13  Distrib 8.0.22, for Linux (x86_64)
--
-- Host: localhost    Database: oregonix_ts
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_wallet_transaction_details`
--

DROP TABLE IF EXISTS `tbl_wallet_transaction_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_wallet_transaction_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `wallet_id` varchar(10) NOT NULL,
  `transaction_for` varchar(100) DEFAULT NULL,
  `transaction_type` enum('FULL','PARTIAL') NOT NULL DEFAULT 'FULL',
  `payee_id` varchar(10) DEFAULT NULL,
  `payee_type` enum('USER','SELLER','PARTNER','ADMIN') DEFAULT NULL,
  `benificiary_id` varchar(10) DEFAULT NULL,
  `benificiary_type` enum('USER','SELLER','PARTNER','ADMIN') DEFAULT NULL,
  `payee_name` text,
  `payee_email` varchar(80) DEFAULT NULL,
  `payee_phone` varchar(10) DEFAULT NULL,
  `benificiary_name` varchar(100) DEFAULT NULL,
  `benificiary_email` varchar(100) DEFAULT NULL,
  `benificiary_phone` varchar(10) DEFAULT NULL,
  `benificiary_holder_name` text,
  `benificiary_account_number` varchar(100) DEFAULT NULL,
  `benificiary_ifsc` text,
  `benificiary_bank_name` text,
  `payee_account_number` varchar(100) DEFAULT NULL,
  `payee_holder_name` text,
  `payee_ifsc` text,
  `payee_bank_name` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_wallet_transaction_details`
--

LOCK TABLES `tbl_wallet_transaction_details` WRITE;
/*!40000 ALTER TABLE `tbl_wallet_transaction_details` DISABLE KEYS */;
INSERT INTO `tbl_wallet_transaction_details` VALUES (5,'68','ADD MONEY TO TRAVPAY','FULL','1','PARTNER','1','PARTNER','Shaun Frost','shaun@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,'69','ADD MONEY TO TRAVPAY','FULL','1','PARTNER','1','PARTNER','Shaun Frost','shaun@mail.com','7042254089','Shaun Frost','shaun@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,'70','TSL-1','FULL','1','PARTNER','1','PARTNER','Shaun Frost','shaun@mail.com','7042254089','Shaun Frost','shaun@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,'71','TSL-3','FULL','1','PARTNER','ADMIN','ADMIN','Shaun Frost','shaun@mail.com','7042254089','ADMIN','ADMIN','ADMIN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,'73','REMIT','FULL','1','PARTNER',NULL,NULL,'Shaun Frost','shaun@mail.com','7042254089',NULL,NULL,NULL,'SHAUN','1234567890','SHAUN1234','SHAUN BANK',NULL,NULL,NULL,NULL),(12,'75','OWN','FULL','1','PARTNER','1','PARTNER','Shaun Frost','shaun@mail.com','7042254089','Shaun Frost','shaun@mail.com','7042254089','Partner1','1234567890','IFSC1','SHAUN BANK',NULL,NULL,NULL,NULL),(14,'78','REQ-3','FULL',NULL,'USER','1','PARTNER','SHAUN','shaun@mail.com','7042254089','Shaun Frost','shaun@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,'79','ADD MONEY TO TRAVPAY','FULL','2','SELLER','2','SELLER','Shaun Frost','shaun1@mail.com','7042254089','Shaun Frost','shaun1@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,'80','OWN','FULL','2','SELLER','2','SELLER','Shaun Frost','shaun1@mail.com','7042254089','Shaun Frost','shaun1@mail.com','7042254089','Seller 1','2345678901','IFSC2','SHAUN BANK',NULL,NULL,NULL,NULL),(17,'81','ADD MONEY TO TRAVPAY','FULL','2','SELLER','2','SELLER','Shaun Frost','shaun1@mail.com','7042254089','Shaun Frost','shaun1@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,'82','TSL-1','FULL','2','SELLER','2','SELLER','Shaun Frost','shaun1@mail.com','7042254089','Shaun Frost','shaun1@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,'83','OWN','FULL','2','SELLER','2','SELLER','Shaun Frost','shaun1@mail.com','7042254089','Shaun Frost','shaun1@mail.com','7042254089','Seller 1','2345678901','IFSC2','SHAUN BANK',NULL,NULL,NULL,NULL),(20,'84','OWN','FULL','2','SELLER','2','SELLER','Shaun Frost','shaun1@mail.com','7042254089','Shaun Frost','shaun1@mail.com','7042254089','Seller 1','2345678901','IFSC2','SHAUN BANK',NULL,NULL,NULL,NULL),(21,'85','OWN','FULL','2','SELLER','2','SELLER','Shaun Frost','shaun1@mail.com','7042254089','Shaun Frost','shaun1@mail.com','7042254089','Seller 1','2345678901','IFSC2','SHAUN BANK',NULL,NULL,NULL,NULL),(22,'86','REMIT','FULL','2','SELLER',NULL,NULL,'Shaun Frost','shaun1@mail.com','7042254089',NULL,NULL,NULL,'SHAUN','1234567890456','879','shaun',NULL,NULL,NULL,NULL),(23,'88','REMIT-TOT','FULL','2','SELLER','2','SELLER','Shaun Frost','shaun1@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,'92','ADD MONEY TO TRAVPAY','FULL','2','SELLER','2','SELLER','Shaun Frost','shaun1@mail.com','7042254089','Shaun Frost','shaun1@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(27,'93','REMIT-UTO','FULL','2','SELLER',NULL,NULL,'Shaun Frost','shaun1@mail.com','7042254089',NULL,NULL,NULL,'SHAUN','7894561230','DBSNMI','SHAUN BANK',NULL,NULL,NULL,NULL),(28,'95','ADD MONEY TO TRAVPAY','FULL','1','PARTNER','1','PARTNER','Shaun Frost','shaun@mail.com','7042254089','Shaun Frost','shaun@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(29,'96','ADD MONEY TO TRAVPAY','FULL','1','PARTNER','1','PARTNER','Shaun Frost','shaun@mail.com','7042254089','Shaun Frost','shaun@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(30,'97','REMIT-UTO','FULL','1','PARTNER',NULL,NULL,'Shaun Frost','shaun@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(31,'99','BK-3-HST-5','PARTIAL','1','PARTNER','2','SELLER','Shaun Frost','shaun@mail.com','7042254089','Shaun Frost','shaun1@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(32,'100','BK-4-HST-6','PARTIAL','1','PARTNER','2','SELLER','Shaun Frost','shaun@mail.com','7042254089','Shaun Frost','shaun1@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33,'103','BK-7-HST-6','FULL','1','PARTNER','2','SELLER','Shaun Frost','shaun@mail.com','7042254089','Shaun Frost','shaun1@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(34,'104','BK-4-HST-6','PARTIAL','1','PARTNER','2','SELLER','Shaun Frost','shaun@mail.com','7042254089','Shaun Frost','shaun1@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(35,'105','ADD MONEY TO TRAVPAY','FULL','1','PARTNER','1','PARTNER','Shaun Frost','shaun@mail.com','7042254089','Shaun Frost','shaun@mail.com','7042254089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tbl_wallet_transaction_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-02 15:49:29
