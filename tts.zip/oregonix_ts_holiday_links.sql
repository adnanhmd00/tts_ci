-- MySQL dump 10.13  Distrib 8.0.22, for Linux (x86_64)
--
-- Host: localhost    Database: oregonix_ts
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `holiday_links`
--

DROP TABLE IF EXISTS `holiday_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `holiday_links` (
  `id` int NOT NULL,
  `links` varchar(255) NOT NULL,
  `city_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holiday_links`
--

LOCK TABLES `holiday_links` WRITE;
/*!40000 ALTER TABLE `holiday_links` DISABLE KEYS */;
INSERT INTO `holiday_links` VALUES (1,'http://thetravelsquare.info/holiday/dubai.html',1),(2,'http://thetravelsquare.info/holiday/bali.html',2),(3,'http://thetravelsquare.info/holiday/goa.html',3),(4,'http://thetravelsquare.info/holiday/mauritius.html',4),(5,'http://thetravelsquare.info/holiday/malaysai.html',5),(6,'http://thetravelsquare.info/holiday/singapore.html',6),(7,'http://thetravelsquare.info/holiday/andaman.html',7),(8,'http://thetravelsquare.info/holiday/maldives.html',8),(9,'http://thetravelsquare.info/holiday/kerala.html',9),(10,'http://thetravelsquare.info/holiday/bangkok-pattaya.html',10),(11,'http://thetravelsquare.info/holiday/vietnam.html',11),(12,'http://thetravelsquare.info/holiday/udaipur.html',12),(13,'http://thetravelsquare.info/holiday/jaipur.html',13),(14,'http://thetravelsquare.info/holiday/agra.html',14),(15,'http://thetravelsquare.info/holiday/delhi.html',15),(16,'http://thetravelsquare.info/holiday/varanasi.html',16),(17,'http://thetravelsquare.info/holiday/mumbai.html',17),(18,'http://thetravelsquare.info/holiday/manali.html',18),(19,'http://thetravelsquare.info/holiday/shimla.html',19),(20,'http://thetravelsquare.info/holiday/mussorie.html',20),(21,'http://thetravelsquare.info/holiday/jodhpur.html',21),(22,'http://thetravelsquare.info/holiday/jaisalmer.html',22),(23,'http://thetravelsquare.info/holiday/kochi.html',23),(24,'http://thetravelsquare.info/holiday/munnar.html',24),(25,'http://thetravelsquare.info/holiday/allepey.html',25),(26,'http://thetravelsquare.info/holiday/gantok.html',26),(27,'http://thetravelsquare.info/holiday/shillong.html',27),(28,'http://thetravelsquare.info/holiday/ranthambore.html',28),(29,'http://thetravelsquare.info/holiday/leh.html',29),(30,'http://thetravelsquare.info/holiday/kaziranga.html',30),(31,'http://thetravelsquare.info/holiday/corbett.html',31),(32,'http://thetravelsquare.info/holiday/khajuraho.html',32),(33,'http://thetravelsquare.info/holiday/dharamshala.html',33),(34,'http://thetravelsquare.info/holiday/kolkata.html',34),(35,'http://thetravelsquare.info/holiday/Rishikesh.html',35),(36,'http://thetravelsquare.info/holiday/darjeeling.html',36),(37,'http://thetravelsquare.info/holiday/fatepursikhri.html',37),(38,'http://thetravelsquare.info/holiday/chennai.html',38),(39,'http://thetravelsquare.info/holiday/banglore.html',39),(40,'http://thetravelsquare.info/holiday/koavlam.html',40),(41,'http://thetravelsquare.info/holiday/pushkar.html',41),(42,'http://thetravelsquare.info/holiday/hampi.html',42),(43,'http://thetravelsquare.info/holiday/amritsar.html',43),(44,'http://thetravelsquare.info/holiday/coorg.html',44),(1,'http://thetravelsquare.info/holiday/dubai.html',1),(2,'http://thetravelsquare.info/holiday/bali.html',2),(3,'http://thetravelsquare.info/holiday/goa.html',3),(4,'http://thetravelsquare.info/holiday/mauritius.html',4),(5,'http://thetravelsquare.info/holiday/malaysai.html',5),(6,'http://thetravelsquare.info/holiday/singapore.html',6),(7,'http://thetravelsquare.info/holiday/andaman.html',7),(8,'http://thetravelsquare.info/holiday/maldives.html',8),(9,'http://thetravelsquare.info/holiday/kerala.html',9),(10,'http://thetravelsquare.info/holiday/bangkok-pattaya.html',10),(11,'http://thetravelsquare.info/holiday/vietnam.html',11),(12,'http://thetravelsquare.info/holiday/udaipur.html',12),(13,'http://thetravelsquare.info/holiday/jaipur.html',13),(14,'http://thetravelsquare.info/holiday/agra.html',14),(15,'http://thetravelsquare.info/holiday/delhi.html',15),(16,'http://thetravelsquare.info/holiday/varanasi.html',16),(17,'http://thetravelsquare.info/holiday/mumbai.html',17),(18,'http://thetravelsquare.info/holiday/manali.html',18),(19,'http://thetravelsquare.info/holiday/shimla.html',19),(20,'http://thetravelsquare.info/holiday/mussorie.html',20),(21,'http://thetravelsquare.info/holiday/jodhpur.html',21),(22,'http://thetravelsquare.info/holiday/jaisalmer.html',22),(23,'http://thetravelsquare.info/holiday/kochi.html',23),(24,'http://thetravelsquare.info/holiday/munnar.html',24),(25,'http://thetravelsquare.info/holiday/allepey.html',25),(26,'http://thetravelsquare.info/holiday/gantok.html',26),(27,'http://thetravelsquare.info/holiday/shillong.html',27),(28,'http://thetravelsquare.info/holiday/ranthambore.html',28),(29,'http://thetravelsquare.info/holiday/leh.html',29),(30,'http://thetravelsquare.info/holiday/kaziranga.html',30),(31,'http://thetravelsquare.info/holiday/corbett.html',31),(32,'http://thetravelsquare.info/holiday/khajuraho.html',32),(33,'http://thetravelsquare.info/holiday/dharamshala.html',33),(34,'http://thetravelsquare.info/holiday/kolkata.html',34),(35,'http://thetravelsquare.info/holiday/Rishikesh.html',35),(36,'http://thetravelsquare.info/holiday/darjeeling.html',36),(37,'http://thetravelsquare.info/holiday/fatepursikhri.html',37),(38,'http://thetravelsquare.info/holiday/chennai.html',38),(39,'http://thetravelsquare.info/holiday/banglore.html',39),(40,'http://thetravelsquare.info/holiday/koavlam.html',40),(41,'http://thetravelsquare.info/holiday/pushkar.html',41),(42,'http://thetravelsquare.info/holiday/hampi.html',42),(43,'http://thetravelsquare.info/holiday/amritsar.html',43),(44,'http://thetravelsquare.info/holiday/coorg.html',44);
/*!40000 ALTER TABLE `holiday_links` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-02 15:49:25
