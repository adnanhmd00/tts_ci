-- MySQL dump 10.13  Distrib 8.0.22, for Linux (x86_64)
--
-- Host: localhost    Database: oregonix_ts
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_deal_image`
--

DROP TABLE IF EXISTS `tbl_deal_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_deal_image` (
  `id` int NOT NULL AUTO_INCREMENT,
  `deal_id` varchar(10) NOT NULL,
  `image` text NOT NULL,
  `position` varchar(10) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_deal_image`
--

LOCK TABLES `tbl_deal_image` WRITE;
/*!40000 ALTER TABLE `tbl_deal_image` DISABLE KEYS */;
INSERT INTO `tbl_deal_image` VALUES (15,'16','http://localhost/TravelSq/uploads/9ddb309af9630485a178f755354b0d402.jpg','0','2020-04-23 10:48:44','2020-04-23 10:48:44',NULL),(17,'16','http://localhost/TravelSq/uploads/3b7adc9e1950b440df837618a50247d5.jpg','1','2020-04-25 18:37:53','2020-04-25 18:37:53','2020-04-25 18:39:20'),(18,'16','http://localhost/TravelSq/uploads/3b7adc9e1950b440df837618a50247d51.jpg','2','2020-04-25 18:39:50','2020-04-25 18:39:50',NULL),(19,'16','http://localhost/TravelSq/uploads/3b7adc9e1950b440df837618a50247d52.jpg','3','2020-04-25 18:41:13','2020-04-25 18:41:13',NULL),(20,'16','http://localhost/TravelSq/uploads/cc5a1ea70d62d3cafa13d382a8c521a4.jpg','3','2020-04-25 18:41:13','2020-04-25 18:41:13',NULL),(21,'16','http://localhost/TravelSq/uploads/16c5dcf6e77c33b9232cc8b8cec30cfb.jpg','4','2020-04-25 18:41:50','2020-04-25 18:41:50',NULL),(22,'18','http://localhost/TravelSq/uploads/3b7adc9e1950b440df837618a50247d53.jpg','0','2020-04-25 21:04:38','2020-04-25 21:04:38',NULL),(23,'19','http://localhost/TravelSq/uploads/25e57ab7e5d01e79818e87dc945b65d9.png','0','2020-05-15 18:07:31','2020-05-15 18:07:31',NULL);
/*!40000 ALTER TABLE `tbl_deal_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-02 15:49:31
