-- MySQL dump 10.13  Distrib 8.0.22, for Linux (x86_64)
--
-- Host: localhost    Database: oregonix_ts
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_hastrek_deal`
--

DROP TABLE IF EXISTS `tbl_hastrek_deal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_hastrek_deal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dealer_id` varchar(10) NOT NULL,
  `dealer_type` varchar(10) NOT NULL,
  `package_name` text NOT NULL,
  `package_type` varchar(2) NOT NULL,
  `trek_type` varchar(10) NOT NULL,
  `from_city` text NOT NULL,
  `destination_city` text NOT NULL,
  `things_to_carry` text NOT NULL,
  `medical_advisory` text NOT NULL,
  `exclusion` text NOT NULL,
  `cancellation_policy` text NOT NULL,
  `refund_policy` text NOT NULL,
  `terms` text NOT NULL,
  `days` varchar(5) NOT NULL,
  `nights` varchar(5) NOT NULL,
  `currency` varchar(10) NOT NULL,
  `price_per` enum('PERSON','DAY') NOT NULL,
  `price_b2b` varchar(10) NOT NULL,
  `price_b2c` varchar(10) NOT NULL COMMENT 'Booking Amount',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_hastrek_deal`
--

LOCK TABLES `tbl_hastrek_deal` WRITE;
/*!40000 ALTER TABLE `tbl_hastrek_deal` DISABLE KEYS */;
INSERT INTO `tbl_hastrek_deal` VALUES (6,'2','seller','Shaun Special','1','2','Greater Noida','Kullu','Nothing','Nothing','NAN','NAN','NAN','NAN','3','2','1','PERSON','','4500','2020-06-21 19:33:40','2020-06-21 19:33:40',NULL);
/*!40000 ALTER TABLE `tbl_hastrek_deal` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-02 15:49:40
