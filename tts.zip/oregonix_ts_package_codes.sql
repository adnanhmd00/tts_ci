-- MySQL dump 10.13  Distrib 8.0.22, for Linux (x86_64)
--
-- Host: localhost    Database: oregonix_ts
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `package_codes`
--

DROP TABLE IF EXISTS `package_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `package_codes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `b2c_cost_per_adult` varchar(255) NOT NULL,
  `b2b_cost_per_adult` varchar(255) NOT NULL,
  `b2c_cost_per_child` varchar(255) NOT NULL DEFAULT '0',
  `b2b_cost_per_child` varchar(255) NOT NULL,
  `package_sharing` varchar(255) NOT NULL,
  `tax` varchar(255) NOT NULL,
  `discount` varchar(255) NOT NULL,
  `booking_amount` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_codes`
--

LOCK TABLES `package_codes` WRITE;
/*!40000 ALTER TABLE `package_codes` DISABLE KEYS */;
INSERT INTO `package_codes` VALUES (1,'TSP101CIA','63400','62000','0','','','','',''),(2,'TSP102CIA','36025','35500','0','','','','',''),(3,'TSP103CIA','','','0','','','','',''),(4,'TSP103CIL','','','0','','','','',''),(5,'TSP103CDL','','21500','0','','','','',''),(6,'TSP104CIA','67500','65500','0','','','','',''),(7,'TSP106CIL','23699','21500','0','','','','',''),(9,'TSP107CIL','12999','11000','0','','','','',''),(10,'TSP108CIL','12000','10000','0','','','','',''),(11,'TSP109CIL','16000','14799','0','','','','',''),(12,'TSP110CIL','24000','22599','0','','','','',''),(13,'TSP111CIL','16000','15000','0','','','','',''),(14,'TSP112CIA','31250','28700','0','','','','',''),(15,'TSP113CIL','25500','22300','0','','','','',''),(16,'TSP114CIL','32800','31099','0','','','','',''),(17,'TSP115CDL','16000','15700','0','','','','',''),(18,'TSP116CIL','40000','38699','0','','','','',''),(19,'TSP117CIL','11000','10800','0','','','','',''),(20,'TSP118CIL','14000','13569','0','','','','',''),(21,'TSP119CIL','37500','36100','0','','','','',''),(22,'TSP120CIL','16000','','0','','','','',''),(23,'TSP121CIL','','','0','','','','',''),(24,'TSP122CIL','12000','10500','0','','','','',''),(25,'TSP123CIL','23750','23500','0','','','','',''),(26,'TSP124CIL','21500','21200','0','','','','',''),(27,'TSP131CIL','19940','16999','0','','','','',''),(28,'TSP132CIL','17000','15449','1','','','','',''),(29,'TSP133CIA','32250','','0','','','','',''),(30,'TSP134CIL','24000','17500','0','','','','',''),(31,'TSP135CIL','22000','17500','0','','','','',''),(32,'TSP136CIL','31750','30500','0','','','','',''),(33,'TSP137CIL','22300','18500','0','','','','',''),(34,'TSP138CIL','26000','23500','0','','','','',''),(35,'TSP139CIA','50500','48250','0','','','','',''),(36,'TSP140CIA','50000','49000','0','','','','',''),(37,'TSP141CIA','52000','50500','0','','','','',''),(38,'TSP142CIL','28000','21500','0','','','','',''),(39,'TSP150CIA','65000','65000','0','','','','',''),(40,'TSP167CDL','18000','12500','0','','','','',''),(41,'TSP168CDL','15000','13500','0','','','','',''),(42,'TSP169CDL','18500','16500','0','','','','',''),(43,'TSP170CIL','16000','14000','0','','','','',''),(44,'TSP171CIL','40000','31000','0','','','','',''),(45,'TSP174CIL','21000','19799','0','','','','',''),(46,'TSP175CIL','27000','25599','0','','','','',''),(47,'TSP176CIL','23500','','0','','','','',''),(48,'TSP178CIL','26000','','0','','','','',''),(49,'TSP191CIL','10000','7000','0','','','','',''),(50,'TSP192CIL','12500','','0','','','','',''),(51,'TSP193CIL','10000','','0','','','','',''),(52,'TSP194CIL','12000','','0','','','','',''),(53,'TSP195CIL','','','0','','','','','');
/*!40000 ALTER TABLE `package_codes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-02 15:49:25
