-- MySQL dump 10.13  Distrib 8.0.22, for Linux (x86_64)
--
-- Host: localhost    Database: oregonix_ts
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `supplier_flight`
--

DROP TABLE IF EXISTS `supplier_flight`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_flight` (
  `id` int NOT NULL AUTO_INCREMENT,
  `supplier_id` varchar(255) NOT NULL,
  `flight_type` varchar(255) NOT NULL,
  `flight_price_type` varchar(255) NOT NULL,
  `airport_from` varchar(255) NOT NULL,
  `airport_to` varchar(255) NOT NULL,
  `departure_time` varchar(255) NOT NULL,
  `arrival_time` varchar(255) NOT NULL,
  `stops` varchar(255) NOT NULL,
  `stop1` varchar(255) DEFAULT NULL,
  `stop2` varchar(255) DEFAULT NULL,
  `stop3` varchar(255) DEFAULT NULL,
  `price` varchar(255) NOT NULL,
  `calendar` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_flight`
--

LOCK TABLES `supplier_flight` WRITE;
/*!40000 ALTER TABLE `supplier_flight` DISABLE KEYS */;
INSERT INTO `supplier_flight` VALUES (1,'','API Check','API Check','API Check','API Check','API Check','API Check','API Check','API Check','API Check','API Check','API Check','API Check'),(2,'','One Way','FD','test','test','test','test','1','test','test','test','test','Passport'),(3,'','One Way','FD','check','check','check','check','1','check','check','check','check','Passport'),(4,'','One Way','FD','1','1','1','1','1','1','1','1','1','Passport'),(5,'','Return','FD','1','1','10:10','10:10','1','1','1','1','1','Passport'),(6,'','Return','FD','1','1','10:10','10:10','1','1','1','1','1','Passport'),(7,'TTSS00015','One Way','FD','1','1','10:10','10:10','1','1','1','1','125','PAN Card'),(8,'TTSS00016','Return','FD','1','1','10:10','10:10','1','1','1','1','112','PAN Card'),(9,'TTSS00016','One Way','FD','1','1','10:10','10:10','2','1','1','1','1','Passport');
/*!40000 ALTER TABLE `supplier_flight` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-02 15:49:33
